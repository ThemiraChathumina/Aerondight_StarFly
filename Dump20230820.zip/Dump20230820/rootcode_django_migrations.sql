-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: rootcode
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2023-08-20 17:58:13.657486'),(2,'auth','0001_initial','2023-08-20 17:58:13.978340'),(3,'admin','0001_initial','2023-08-20 17:58:14.054174'),(4,'admin','0002_logentry_remove_auto_add','2023-08-20 17:58:14.062289'),(5,'admin','0003_logentry_add_action_flag_choices','2023-08-20 17:58:14.070436'),(6,'app','0001_initial','2023-08-20 17:58:14.795579'),(7,'app','0002_rename_planets_planet','2023-08-20 17:58:15.193104'),(8,'app','0003_remove_paymentmethods_user_id','2023-08-20 17:58:15.236871'),(9,'app','0004_paymentmethods_user_id','2023-08-20 17:58:15.287634'),(10,'app','0005_rename_bookings_booking_and_more','2023-08-20 17:58:15.968937'),(11,'app','0006_seat_remove_flightschedule_flight_group_id_and_more','2023-08-20 17:58:16.102743'),(12,'app','0007_remove_planet_planet_photo_link_and_more','2023-08-20 17:58:16.145859'),(13,'app','0008_remove_destinations_destination_photo_link','2023-08-20 17:58:16.175484'),(14,'app','0009_remove_flightschedule_flight_photo_link','2023-08-20 17:58:16.201855'),(15,'app','0010_remove_booking_departure_date_and_more','2023-08-20 17:58:16.532771'),(16,'app','0011_booking_departure_date_booking_destination_and_more','2023-08-20 17:58:16.789037');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-20 23:57:15
